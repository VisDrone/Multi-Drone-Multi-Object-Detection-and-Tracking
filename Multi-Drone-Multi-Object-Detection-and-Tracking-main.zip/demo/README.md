# Demo

Please refer to the inference of [VID](../docs/en/quick_run.md#inference-vid-models), [MOT](../docs/en/quick_run.md#inference-motvis-models), [SOT](../docs/en/quick_run.md#inference-sot-models) and [VIS](../docs/en/quick_run.md#inference-motvis-models) to run demos.
