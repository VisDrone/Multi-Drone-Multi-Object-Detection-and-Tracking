import json  # 导入json模块，用于处理JSON格式的数据
import os  # 导入os模块，用于与操作系统进行交互，如文件和目录操作
from argparse import ArgumentParser  # 导入ArgumentParser类，用于处理命令行参数



parser = ArgumentParser()
parser.add_argument('--sequences_result',
                    default="./Multi-Drone-Multi-Object-Detection-and-Tracking-main/dataset/MDMT_dataset/json_resultfiles2/NMS-one_carafe_bytetrack_full_mdmt/",
                    help="input file directory")
parser.add_argument('--output_dir',
                    default="./Multi-Drone-Multi-Object-Detection-and-Tracking-main/demo/txt/MOT/NMS-one_carafe_bytetrack_full_mdmt/",
                    help="input file directory")
args = parser.parse_args()

input_dir = args.sequences_result
# input_dir = "./json_resultfiles/Firstframe_initialized_bytetrack_autoassign_full_mdmt-private-half/"


json_files_dirs = os.listdir(input_dir)

for file in json_files_dirs:
    print(file)
    if "txt" in file or "ipynb" in file:
        continue
    # if file not in ["26-1.json", "26-2.json"]:
    #     continue
    json_dir = os.path.join(input_dir, file)
    sequence = json_dir.split("/")[-1]
    sequence = sequence.split(".")[0]
    # print(sequence)
    # print(json_dir)
    n = 0
    maxID = 0
    with open(json_dir) as f:
        load_json = json.load(f)
        if not os.path.exists(args.output_dir):
            os.makedirs(args.output_dir)
            
        with open("{0}/{1}.txt".format(args.output_dir, sequence), "w") as f_txt:
            # 两个循环分别遍历字典的键值对
            for (key, values) in load_json.items():
                for value in values:
                    maxID = max(maxID, value[0])
                    print(maxID)
            while n <= maxID:
                for (key, values) in load_json.items():
                    # print(key)
                    frame = key.split("=")[-1]
                    # 先找ID=1的
                    for value in values:
                        if value[0] == n:
                            string_line = "{0},{1},{2},{3},{4},{5},{6},{7},{8}\n".format(int(frame), int(value[0]),
                                                                                         value[1], value[2],
                                                                                         value[3] - value[1],
                                                                                         value[4] - value[2], int(1),
                                                                                         int(1), int(1))
                            f_txt.write(string_line)

                    # if key == "frame={}".format(n):
                    #     print("bigin")

                    # for value in values:
                    #     # print(value)
                    #     frame = key.split("=")[-1]
                    #     string_line = "{0},{1},{2},{3},{4},{5},{6},{7},{8}\n".format(frame, value[0], value[1], value[2], value[3], value[4], int(1), int(3), int(1))
                    #     f_txt.write(string_line)
                n += 1




