# Usage of MOT configs

## Training with MOT configs

Please refer to [Train MOT models](../../docs/en/quick_run.md#examples-of-training-mot-model) to see the examples.

## Testing with MOT configs

Please refer to [Test MOT models](../../docs/en/quick_run.md#examples-of-testing-mot-model) to see the examples.

## Inference with MOT configs

Please refer to [Inference MOT models](../../docs/en/quick_run.md#inference-motvis-models) to see the examples.
