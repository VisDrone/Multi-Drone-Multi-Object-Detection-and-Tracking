# Usage of configs

## Training with configs

Please refer to [Training](../docs/en/quick_run.md#training) to see the tutorials of training models.

## Testing with configs

Please refer to [Testing](../docs/en/quick_run.md#testing) to see the tutorials of testing models.

## Inference with configs

Please refer to [Inference](../docs/en/quick_run.md#inference) to see the tutorials of inferencing models.
