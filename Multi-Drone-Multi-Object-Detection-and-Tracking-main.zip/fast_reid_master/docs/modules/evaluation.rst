fastreid.evaluation
=============================

.. automodule:: fastreid.evaluation
    :members:
    :undoc-members:
    :show-inheritance:
