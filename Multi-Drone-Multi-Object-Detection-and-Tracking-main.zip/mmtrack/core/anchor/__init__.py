# Copyright (c) OpenMMLab. All rights reserved.
from .sot_anchor_generator import SiameseRPNAnchorGenerator

__all__ = ['SiameseRPNAnchorGenerator']
