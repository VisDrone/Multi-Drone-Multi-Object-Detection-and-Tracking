# Copyright (c) OpenMMLab. All rights reserved.
from .region_iou_calculator import calculate_region_overlap

__all__ = ['calculate_region_overlap']
