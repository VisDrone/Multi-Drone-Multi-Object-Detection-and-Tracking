# Copyright (c) OpenMMLab. All rights reserved.
from .sot_resnet import SOTResNet

__all__ = ['SOTResNet']
