# Copyright (c) OpenMMLab. All rights reserved.
from .coco_video_parser import CocoVID

__all__ = ['CocoVID']
